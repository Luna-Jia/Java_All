package edu.wccnet.mejia;

public class Chickadee {
    public String getEatHabit() {
        return "I eat seed.";
    }
}
