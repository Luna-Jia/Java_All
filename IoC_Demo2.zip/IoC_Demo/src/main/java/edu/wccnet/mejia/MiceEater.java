package edu.wccnet.mejia;

public class MiceEater implements IBird{
    @Override
    public String getEatingHabit() {
        return "I eat mice.";
    }
}
