package edu.wccnet.mejia;

public class Owl {
    public String getEatHabit(){
        return "I eat mice";

    }
}
