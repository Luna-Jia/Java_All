package edu.wccnet.mejia;

public interface IBird {
    String getEatingHabit();
}
