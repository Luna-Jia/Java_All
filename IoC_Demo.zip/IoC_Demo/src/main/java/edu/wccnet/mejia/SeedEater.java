package edu.wccnet.mejia;

public class SeedEater implements IBird {
    @Override
    public String getEatingHabit() {
        return "I eat seeds.";
    }
}
